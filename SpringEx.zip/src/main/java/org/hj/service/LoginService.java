package org.hj.service;

import org.hj.model.LoginVO;

public interface LoginService {

	public LoginVO login(LoginVO member);
	
}
