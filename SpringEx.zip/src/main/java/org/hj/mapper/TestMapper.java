package org.hj.mapper;

public interface TestMapper {
	//     리턴타임   메소드명();   마지막에 ;으로 끝났으니까 추상메서드
	public String getTime();
	
}
