package org.hj.mapper;

import org.hj.model.LoginVO;

public interface LoginMapper {

	public LoginVO login(LoginVO member);
}
